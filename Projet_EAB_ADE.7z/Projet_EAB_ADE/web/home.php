<?php
	#################################################################
	#
	#	Programme:		home.php
	#	Auteur:		    Alan Dsz
	#	Classe:			Info 3A
	#
	#################################################################

	// start
	session_start();

	// inclure le fichier de conf
	include 'conf.inc.php';
?>

<html>
	<head>
		<title>Site de l'office du tourisme - Home </title>
	</head>
	
<?php
	// include head+body+foot
	include 'header.php';
	include 'body.php';
	include 'footer.php';
?>
