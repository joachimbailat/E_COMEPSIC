<?php
	#################################################################
	#
	#	Programme:		Excursions.php
	#	Auteur:		    Alan Dsz
	#	Classe:			Info 3A
	#
	#################################################################

	
	// start
	session_start();

	// Title
	echo "<head> <title> Tourisme - Excursions </title> </head>";
	
	// include du fichier de conf
	include 'conf.inc.php';
	
	//	check if user is connect
	if(!isset($_SESSION['name']))
	{
		// Redirection sur la page d'inscription 
		echo "<script>alert('Il faut \352tre inscrit et connect\351 sur le site pour avoir acc\350s \340 la liste des excursions !!!');</script>";
		header('Refresh: 0.5;url=user_registry.php');
		exit;
	}	
		// include header
		include 'header.php';
	
		// Permet dafficher les données de manière formatée depuis un fichier .CSV 
		// Initialisation de variable 
		echo "<table>";
		$fichier = $DocumentRoot . $files_path . "excursions.csv"; 
		$fic = fopen($fichier, 'rb'); 
		
		$nb_lignes=0;		//nombre de lignes
		$nb_lignes_max=25; 	//nombre max de lignes a afficher
		$nb_colonnes_max=5;	//nombre max de colonnes a afficher
		
		// Boucle qui permet d'afficher les données
		for ($ligne = fgetcsv($fic, 1024, ";"); !feof($fic); $ligne = fgetcsv($fic, 1024, ";")) 
		{ 
			if($nb_lignes<$nb_lignes_max)
			{
				echo "<tr>"; 
				$j = sizeof($ligne); 
				if($j>$nb_colonnes_max)
				{
					$j=$nb_colonnes_max;
				} 
				for ($i = 0; $i < $j; $i++) 
				{ 
					echo "<td>".$ligne[$i]."</td>"; 
				}
				echo "</tr>"; 
			}
			$nb_lignes++;
		} 
		echo "</table>\n";
?>

<!-- Affichage des images -->
<tr>
	<td><img src="<?php echo "..".$items_path."1.jpg";?>" style="border:none"width="20%" height="20%"></td>
	<td><img src="<?php echo "..".$items_path."2.jpg";?>" style="border:none"width="20%" height="20%"></td>
	<td><img src="<?php echo "..".$items_path."3.jpg";?>" style="border:none"width="20%" height="20%"></td>
	<td><img src="<?php echo "..".$items_path."4.jpg";?>" style="border:none"width="19%" height="20%"></td>
	<td><img src="<?php echo "..".$items_path."default.jpg";?>" style="border:none"width="19%" height="20%"></td>
<tr>
	
<!-- include du footer -->
<?php include 'footer.php'; ?>

