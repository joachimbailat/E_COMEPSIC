<?php
	#################################################################
	#
	#	Programme:		body.php
	#	Auteur:		    Alan Dsz
	#	Classe:			Info 3A
	#
	#################################################################

?>
		<!-- body -->
		<tr>
			<td colspan=5><img src="<?php echo "..".$pictures_path."body.jpg";?>" style="border:none"width="100%"></td>
		</tr>
		<tr>
			<td colspan=5> <font size="3">  &copy; 2009 - Fondation Suisse Mobile - http://www.suissemobile.ch </font> </td>
		</tr>
		<tr>
			<td> <br /> </td>
		</tr>