<?php
	#################################################################
	#
	#	Programme:		logoff.php
	#	Auteur:		    Alan Dsz
	#	Classe:			Info 3A
	#
	#################################################################


// start
session_start();

// erase table
$_SESSION = array(); 

// destroy session
session_unset();
session_destroy();

// redirection automatique vers home.php
header('location:Home.php');
exit;
?>