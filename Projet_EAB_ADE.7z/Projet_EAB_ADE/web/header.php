<?php
	#################################################################
	#
	#	Programme:		header.php
	#	Auteur:		    Alan Dsz
	#	Classe:			Info 3A
	#
	#################################################################
	
		
?>
	<!-- On click suisse mobile -->
	<body vlink="white" alink="white" link="white">
	  	<table width="100%"  border="0">
			<tr>
				<td align="right" colspan=5>
					<a href="http://www.suissemobile.ch"  onclick="window.open(this.href); return false;">
						<img src="<?php echo "..".$pictures_path."logo_smo.gif";?>" style="border:none" width="80" height="80"> 
					</a>
				</td>
			</tr>
			
	<!-- body -->
	<tr> 
		<td width="15%" style="background:#0404B4; color:white" align="center" height="30pt"> <a href="home.php"> <big> <b> Home </b> </big> </a> </td>
		<td width="20%" style="background:#0404B4; color:gray" align="center" height="30pt"> <?php 
							// L'utilisateur existe-t-il dans la sess
							if ( isset($_SESSION['name'] ) )
							{	
								// OUI afficher Excursions.php
								echo "<a href='Excursions.php' onclick='return true'> <big> <b> Excursions </b> </big> </a>";
							}
							else
							{	
								// NON afficher Excursions sans liens
								echo "<a Disabled='true'> <big> <b> Excursions </b> </big> </a>";
							}
						 ?> </td>
		
		<td width="25%" style="background:#0404B4; color:white" align="center" height="30pt"> <a href="http://www.cff.ch"  onclick="window.open(this.href); return false;"> <big> <b> Agence CFF </b> </big> </a> </td>
		<td width="12%" style="background:#0404B4; color:white" align="center" height="30pt"> <a href="Login.php" > <big> <b> Login </b> </big> </a> </td>
		<td style="background:#0404B4; color:white" align="center" height="30pt"> <big> <b> User: <?php 	
								// dernier user est dans la sess?
								if ( isset($_SESSION['name'] ) )
								{
									// OUI affiche le nom de sess
									$pseudo=$_SESSION['name'];
									echo $pseudo;
								} 
								else
								{
									// NON Affiche des point .....
									echo "....";
								}
								echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
							   
								// user est dans la sess ? 
								if ( isset($_SESSION['name'] ) )
								{
									// OUI Affiche logoff
									echo "<a href='logoff.php'> logoff</a>";
								} 
							  ?> </b> </big> </td>
	</tr>
	<tr>
		<td> <br /> </td>
	</tr>



















	
<!--  Pour ouvrir fenetre dans un pop up -->			
<!--  onclick="open('Login.php', 'Popup', 'scrollbars=1,resizable=1,height=560,width=770'); return false;" -->