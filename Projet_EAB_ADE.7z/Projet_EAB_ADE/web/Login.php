<?php
	#################################################################
	#
	#	Programme:		Login.php
	#	Auteur:		    Alan Dsz
	#	Classe:			Info 3A
	#
	#################################################################
	// start
	session_start();
	
	// include du fichier de conf
	include 'conf.inc.php';


	// Liste des users
	$users=array();								

	// ID
	$pseudo='';					// Nom du dernier user
	$message_erreur='';			// Message 	
	$data_log = array();		// info login
	
	// Le nom du dernier utilisateur est dans le cookie ?
	if ( isset($_COOKIE['UserName'] ) )
	{
		$pseudo=$_COOKIE['UserName'];
	}
		
	if ( isset($_POST['submit']) )
	{
		// Authentification - UTILISATEUR et MOT DE PASSE
		include("verif.inc.php");
	
		// formulaire compl�ts ?
		if (  $_POST['pseudo']!='' &&  $_POST['motpasse']!=''  )
		{ 
			// OUI
			// m�morisation des datas
			$user = $_POST['pseudo'] ; 
			$pwd = $_POST['motpasse'];
			
			// �nclude log.inc.php
			include("log.inc.php");
			
			// m�mo info pour log files
			$data_log['user_name']=$user;
			$data_log['time_date']=strftime('%d.%m.%y/%H:%M:%S',$_SERVER['REQUEST_TIME']);
			$data_log['client_ip']=$_SERVER['REMOTE_ADDR'];
			$data_log['client_browser']=$_SERVER['HTTP_USER_AGENT'];
  			
	
			//  nom+mdp valide ? 
			if ( verification($user, $pwd, $users ) )
			{ 
				// OUI
				// user est identifi� 
				// change d'ID (pour plus de s�curit�) 
				session_regenerate_id();
		
				// On m�morise son nom utilisation futur
				$_SESSION['name']=$user;

				// m�morisation statut dans le log files
				$data_log['session']='session good';
				
				// save data LOG
				save_data($log_path, $log_file, $data_log);

				// M�morisation de l'utilisateur est-elle souhait�e?
				if ( isset($_POST['memo']) )
				{
					if ($_REQUEST['memo']=='yes')
					{
						// OUI
						// Pseudo m�moris� dans un cookie pour 30 min
						setcookie('UserName',$user,time()+1800);
					}
					else
					{
						// NON
						// Cookie vid�
						setcookie('UserName');
					}
				}
			
				// Lien vers la page qui n�cessite une authentification
				header('location:Excursions.php');
				exit();
			}
			else
			{
				// NON
				// user pas valide 
				$message_erreur = '<br/>Le pseudo ou le mot de passe entr&eacute; n\'est pas valide! <br/><br/><br/>' ; 
				
				// m�morisation statut files log
				$data_log['session']='session failed';
				
				// save data to LOG
				save_data($log_path, $log_file, $data_log);
			}
		}
		else
		{
			// NON
			// Message d'erreur
			$message_erreur ='<br/>Veuillez compl�ter tous les champs ! <br/><br/><br/>'; 
		}
	}

?>

<!-- "Tourisme - Login" -->		
	<head>
		<title> Tourisme - Login </title>
	</head>

		<!-- include header dans tR -->
		<tr>
			<td><?php include 'header.php'; ?>	</td>
		</tr>
		<!-- FORMULAIRE -->	
		<tr align="center">
			<td colspan=5>
				<form method="post" action="Login.php">
					<h2>Page d'authentification</h2>
						<?php
							//Message d'erreur de saisie des donn�es si erreur il y a 
							if ( $message_erreur != '')
							{
								echo'<p><font color="black">'.$message_erreur.'<font/><font color="black"><font/></p>';
							}
						?>				
					<p> 
						<label for="nom">USERNAME: </label> 
						<input type="text" name="pseudo" value="<?php echo $pseudo; ?>"> 
					</p> 
					<p> 
						<label for="motdepasse">PASSWORD : </label> 
						<input type="password" name="motpasse"> 
					</p>
					<p> 
						<input type="hidden" name="memo" value="no">
						<input type="checkbox" name="memo" value="yes" checked>Sauvegarder les informations ?  <br/><br/>
					</p> 
					<p> 
						<input type="submit" name="submit"value="Log in"> 
					</p>	
				</form> 
			</td>
		</tr>
	
		<!-- Ligne <tr> contenant le pied de page (un bout du menu) -->
		<tr>
			<td colspan = 5> <?php include 'footer.php'; ?>	</td>
		</tr>
