<?php
	#################################################################
	#
	#	Programme:		registry.inc.php
	#	Auteur:		    Alan Dsz
	#	Classe:			Info 3A
	#
	#################################################################
	
	
	// include du fichier de conf
	include 'conf.inc.php';						
		
	// sauvegarde des données de tentative d'ouverture de session
	function registry(&$users_path, &$users_file, &$registry_data)
	{
		// Ouverture du fichier CSV 
		// Le caractère @ supprime toute éventuel E_WARNING si le fichier n'est pas disponible
		if ( $handle = @fopen($users_path.$users_file, "a") )
		{	
			// Récup data dans tableau
			fputcsv($handle,$registry_data,';');
										
			// close
			fclose($handle);
		}
		else
		{
			// Base de données indisponible
			// Create fichier temp
			$registry_file_tmp = strftime('%d%m%y_%H%M%S',$_SERVER['REQUEST_TIME']).'.tmp.csv';
			
			// open file temp
			// Le caractère @ supprime toute éventuel E_WARNING si le fichier ne peux pas être crée
			if ( $handle = @fopen($users_path.$registry_file_tmp, "w") )
			{
			
				// ajoute le délimiteur CSV au données écrites
				fputcsv($handle,$registry_data,';');
											
				// close
				fclose($handle);
			}
		}
	}
?>