<?php
	#################################################################
	#
	#	Programme:		verif.inc.php
	#	Auteur:		    Alan dsz
	#	Classe:			Info 3A
	#
	#################################################################

	// include du fichier de conf
	
	include 'conf.inc.php';						
	
	//  v�rification du user et du mot de passe
	
		function verification($nom, $pass, &$data)
		{
			$verify = false;
		
			for ($x=0; $x < count($data); $x++)
			{
				if ( ($data[$x][0] == $nom) && ($data[$x][1] == md5($pass)) )
				{
					$verify = true;
					break;
				}
			}
		
			return ($verify);
		}

	// Chargement des donn�es USERS et MDP depuis le fichier 
		// Le dossier existe ?
		if( is_dir($users_path) )
		{
			// opening
			if( $path = opendir($users_path) )
			{
				// reading
				while( ($file = readdir($path)) != FALSE )
				{
					// it is a data file ?
					if( $file != '.' && $file != '..' )
					{
						// it's the good one ?
						if ( $file == $users_file )
						{
							// opening reading files
							$handle = fopen($users_path.$file, "r");
						
							// Titres des colonnes 
							fgetcsv($handle, 1000, ";");
						
							// Tableau des donn�es utilisateurs
							$index = 0;
						
							// M�morisation des donn�es user et mdp
							while ( ($data = fgetcsv($handle, 1000, ";")) !== FALSE )
							{    
								// R�cup�re les donn�es dans un tableau (2D)
								foreach ($data as $key => $value)
								{
									$users[$index][$key]=$value;
								}
							
								// Incr�mente
								$index++;
							}
											
							// close
							fclose($handle);
						}
						else
						{
							//  warning
							echo 'Le fichier des donn�es n\'existe pas ou n\'est pas disponible pour l\'instant...<br/>';
						}
					}
				}
			}
	
			// close
			closedir($path);
		}
		else
		{
			// waring
			echo 'Le dossier des donn�es n\'existe pas ou n\'est pas disponible pour l\'instant...<br/>';
		}
?>