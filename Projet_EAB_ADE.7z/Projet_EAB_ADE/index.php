

<?php

	#################################################################
	#
	#	Programme:		index.php
	#	Auteur:		    Alan Dsz
	#	Classe:			Info 3A
	#
	#################################################################



	// Call de home.php
	header('location:./web/home.php');
?>






