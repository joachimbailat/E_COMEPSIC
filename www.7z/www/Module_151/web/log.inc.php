<?php
	#################################################################
	#
	#	Programme:		log.inc.php
	#	Auteur:		   	Alan Dsz
	#	Classe:			Info 3A
	#
	#################################################################

	
	// include du fichier de conf
	include 'conf.inc.php';					
	
	// Fonction de sauvegarde des données log in dans un log file
	function save_data(&$log_path, &$log_file, &$data_log)
	{
		// Ouverture du fichier CSV 

		// Le caractère @ supprime toute éventuel E_WARNING si le fichier n'est pas disponible
		if ( $handle = @fopen($log_path.$log_file, "a") )
		{	
			// Récup data dans un tableau
			fputcsv($handle,$data_log,';');
	
										
			// close
			fclose($handle);
		}
		else
		{
			// Message d'avertissement
			echo 'Le fichier des données log n\'est pas disponible pour l\'instant...<br/>';
			
			// Création fichier temp
			$log_file_tmp = strftime('%d%m%y_%H%M%S',$_SERVER['REQUEST_TIME']).'.tmp.csv';
			
			// Ouverture fichier temp
			// Le caractère @ supprime toute éventuel E_WARNING si le fichier ne peux pas être crée
			if ( $handle = @fopen($log_path.$log_file_tmp, "w") )
			{
			
				// Récup data dans un tableau
				fputcsv($handle,$data_log,';');
											
				// close
				fclose($handle);
			}
		}
	}
?>