<?php
	##########################################
	#	Programme:		conf.inc.php
	#	Auteur:		    Alan Dsz
	#	Classe:			Info 3A
	#
	##########################################
	
	// Définir les dossiers de base
	$DocumentRoot = $_SERVER["DOCUMENT_ROOT"]."/Projet_EAB_ADE";  // Dossier racine
	$pictures_path = "/pictures/";	// images
	$files_path = "/files/";	// fichiers
	$items_path = "/items/";	// items
	
	// définir log.inc.php
	$log_path = $DocumentRoot.'/logs/';		// Dossier du LOG
	$log_file = 'log.csv';					// Fichier LOG
	
	// définir registry.inc.php
	// définir verif.inc.php
	$users_path= $DocumentRoot."/users/";		// Dossier du file users
	$users_file= "users.csv";					// Fichier users
	
	// définir Mention légales
	$mention_file= "/MentionLegal.txt";			// Fichier .txt
	
	mb_internal_encoding('UTF-8');				// encodage UTF-8
?>
	<!-- PAs de lien hypertexte souligné -->	
	<style> a{ text-decoration:none; } </style> 