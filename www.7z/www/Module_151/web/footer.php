<?php
	#################################################################
	#
	#	Programme:		footer.php
	#	Auteur:		    Alan  Dsz
	#	Classe:			Info 3A
	#
	#################################################################

	
	// include du fichier de conf
	include 'conf.inc.php';
?>
<!-- Footer -->
			<table width="100%" border="0">
				<tr style="background:#0404B4; color:white" align="center" height="30pt"> 
					<td width="20%"> <a href="mailto:info@officetourisme.ch?subject=Demande de contact"> <big> <b> Contact </b> </big> </a> </td>
					<td width="40%"> <a href= <?php echo "..".$files_path."Tabelle_Degres_de_difficulte.pdf";?>  onclick="window.open(this.href); return false;"> <big> <b> Degr&eacute;s de difficult&eacute; </b> </big> </a> </td>
					<td width="20%"> <a href="user_registry.php" > <big> <b> Newsletter </b> </big> </a> </td>
					<td width="20%"> <a href="Impressum.php" > <big> <b> Impressum </b> </big> </a> </td>
				</tr>
			</table>
		</table>
	</body>
</html>
