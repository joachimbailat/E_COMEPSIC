<?php
	#################################################################
	#
	#	Programme:		Impressum.php
	#	Auteur:		    Alan Dsz
	#	Classe:			Info 3A
	#
	#################################################################

	
	// Start
	session_start();
	
	// include du fichier de conf
	include 'conf.inc.php';						
?>

<!-- Title -->	
	<head>
		<title> Tourisme - Impressum </title>
	</head>
	
		<!-- Header -->	
		<tr> <td> <?php include 'header.php'; ?> </td> </tr>
		
		<tr>
			<td colspan = 5>
				<?php
					//Le fichier existe ?
					if( is_file($DocumentRoot.$files_path.$mention_file) )
					{
						// OUI
						// Affiche le fichier
						echo '</br>';
						// nl2br insère un retour à la ligne à chaque nouvelle ligne
						echo nl2br(file_get_contents($DocumentRoot.$files_path.$mention_file));
						echo '</br></br>';
					}
					else
					{
						// NON
						// Affiche message d'erreur
						echo '</br></br></br>Mentions légales momentanément indisponible. </br></br></br>';
					}
				?>
			</td>
		</tr>
		
		<!-- Footer -->
		<tr> <td colspan = 5> <?php include 'footer.php'; ?> </td> </tr>
