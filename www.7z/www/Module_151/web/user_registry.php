<?php
	#################################################################
	#
	#	Programme:		user_registry.php
	#	Auteur:		    Alan Dsz
	#	Classe:			Info 3A
	#
	#################################################################

	
	// start
	session_start(); 
	
	// include du fichier de conf
	include 'conf.inc.php';			
	$IndexFields = array("UserName","Password","ConfirmPassword","Nom","Prenom","Email"); // Index
	$ErrorFieldsForm = array();		// Tableau d'erreurs
	$FieldsValues = array();		// Tableau des valeurs saisie
	
	// Créationn des tableaux des valeurs et des erreurs
	foreach($IndexFields as $Index)
	{
		$ErrorFieldsForm[$Index] = "";
		$FieldsValues[$Index] = "";
	}
	
	// Fonction de mémorisation des données dans la base (fichier CSV)
	include('registry.inc.php');


	// Test si bouton ENVOYER a déjà été pressé
	if( isset($_POST['VALIDER']) )
	{
		$VerifyForm = true;	// Formulaire valide
	
		// Recherche les champs v
		foreach($_POST as $Key => $Value)
		{
			if($Value == "")
			{
				// Si vide affiche erreur
				$ErrorFieldsForm[$Key] = "<b><font color=#ff0000><- Veuillez compl&eacute;ter le champs SVP.</font></b>";
				$VerifyForm = false; // Formulaire pas valide
			}
			else
			{
				// Est-ce le champs VALIDER ?
				if ($Key == "VALIDER")
				{
					// Si OUI
					// Assigner STATUS = USER
					$FieldsValues[$Key] = "USER";
				}
				else
				{
					//Si NON
					// Assigne les valeurs correspondantes aux champs
					$FieldsValues[$Key] = $Value;
				}	
			}
		}
		
		// test de vérification si les 2 mot de passe sont identique
		if ($FieldsValues['ConfirmPassword'] !== $FieldsValues['Password'])
		{
			$ErrorFieldsForm['ConfirmPassword'] = "<b><font color=#ff0000><- Les 2 mot de passe ne correspondent pas.</font></b>";
			$VerifyForm = false; // Formulaire pas valide
		}
		// test de vérification si l' E-mail est dans un bon format
		if (filter_var($FieldsValues['Email'], FILTER_VALIDATE_EMAIL) OR $FieldsValues['Email'] == "") 
		{
			//Si bon format on ne fait rien
		}
		else
		{
			$ErrorFieldsForm['Email'] = "<b><font color=#ff0000> <- Cet email a un format non adapt&eacute;.</font></b>";
			$VerifyForm = false; // Formulaire pas valide
		}

		// Si formulaire complet
		if ( $VerifyForm )
		{
			// Cryptage du mot de passe !!!
			$FieldsValues['Password'] = md5($FieldsValues['Password']);
			$FieldsValues['ConfirmPassword'] = md5($FieldsValues['ConfirmPassword']);
				
			// Sauvegarde des données dans le fichier !!!
			registry($users_path, $users_file, $FieldsValues);
				
			// Prochain lien -> Login
			header('location:login.php'); 
			exit;
		}
			
	}
?>
<!-- Construction de la page HTML "Tourisme - Inscriptions" -->	
	<head>
		<title> Tourisme - Inscriptions </title>
	</head>
	
	<!-- Ligne <tr> contenant l'en-tête de page (un bout du menu) -->
	<tr>
		<td><?php include 'header.php'; ?>	</td>
	</tr>

	<!-- formulaire inscription -->
	<table>
		<tr>
			<td>
				<h1>Formulaire d'enregistrement</h1>
				<h3> <FONT COLOR="red" > Tous les champs doivent &ecirc;tre remplis.    Merci!</font> </h3> <br/>
				
				<!-- Formulaire  -->
				<form name="Formulaire ENREGISTREMENT" id="ENREGISTREMENT" method="post" action="user_registry.php">
					<table>
						<tr>
							<!-- Champ Nom  -->
							<td><label for="Username"><b>Nom d'utilisateur : </b></label></td>
							<td><input type="text" name="UserName" id="Username" size=50 value="<?php echo $FieldsValues['UserName'];?>"></td>
							<td><?php echo $ErrorFieldsForm['UserName'];?></td>
						</tr>
						<tr>
							<!-- Champ Mdp-->
							<td><label for="Password"><b>Mot de Passe : </b></label></td>
							<td><input type="password" name="Password" id="Password" size=50 value="<?php echo $FieldsValues['Password'];?>"></td>
							<td><?php echo $ErrorFieldsForm['Password'];?></td>
						</tr>
						<tr>
							<!-- Champ Confirmation -->
							<td><label for="Password"><b>Confirmation : </b></label></td>
							<td><input type="password" name="ConfirmPassword" id="ConfirmPassword" size=50 value="<?php echo $FieldsValues['ConfirmPassword'];?>"></td>
							<td><?php echo $ErrorFieldsForm['ConfirmPassword']; ?></td>
						</tr>
						<tr>
							<!-- Champ Nom -->
							<td><label for="Nom"><b>Nom: </b></label></td>
							<td><input type="text" name="Nom" id="Nom" size=50 value="<?php echo $FieldsValues['Nom'];?>"></td>
							<td><?php echo $ErrorFieldsForm['Nom'];?></td>
						</tr>
						<tr>
							<!-- Champ Prénom -->
							<td><label for="Prenom"><b>Pr&eacute;nom : </b></label></td>
							<td><input type="text" name="Prenom" id="Prenom" size=50 value="<?php echo $FieldsValues['Prenom'];?>"></td>
							<td><?php echo $ErrorFieldsForm['Prenom'];?></td>
						</tr>
						<tr>
							<!-- Champ E-mail -->
							<td><label for="Email"><b>E-mail : </b></label></td>
							<td><input type="text" name="Email" id="Email" size=50 value="<?php echo $FieldsValues['Email'];?>"></td>
							<td><?php echo $ErrorFieldsForm['Email'];?></td>
						</tr>						
					</table>
					<br/>
					<!-- Valider -->
					<input name="VALIDER" type="submit" value="VALIDER">
					<br/>
					<br/>
				</form>
			</td>
		</tr>
	</table>

	<!-- include footer-->
	<tr>
		<td colspan = 5> <?php include 'footer.php'; ?>	</td>
	</tr>

